<div class="menu-item" id="menu-home"><div class="menu-text" >Home</div></div>
<div class="menu-item" id="menu-admin"><div class="menu-text" >Admin</div></div>
<div class="menu-item" id="menu-logs"><div class="menu-text" >Logs</div></div>
<div class="menu-item" id="menu-new"><div class="menu-text" >Create</div></div>
<div class="menu-item" id="menu-logout"><div class="menu-text" >Logout</div></div>