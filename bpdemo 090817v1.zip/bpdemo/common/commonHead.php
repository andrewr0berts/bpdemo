<!--favicon and title-->
<link rel="icon" href="http://www.bpdemo.com/favicon.png">
<title>Services App</title>

<!--Style sheets-->
<link href="../css/bpdemo.css" rel="stylesheet" type="text/css"/>
<link href="../js/jquery-ui-1.12.1.custom/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
<link href="../css/jquery.dataTables.css" rel="stylesheet" type="text/css"/>

<!--scripts-->
<script src="../js/jquery-2.1.4.min.js" type="text/javascript"></script>
<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBOaAyA26UY5iOTWdm7jDXc6V_zLB29UJs&callback=initMap" type="text/javascript"></script>-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBOaAyA26UY5iOTWdm7jDXc6V_zLB29UJs&callback=initMap" type="text/javascript"></script>
<script src="../js/jquery-ui-1.12.1.custom/jquery-ui.min.js" type="text/javascript"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script src="../js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="../js/jquery.ui.touch-punch.min.js" type="text/javascript"></script>
<script src="../js/windowSetup.js" type="text/javascript"></script>